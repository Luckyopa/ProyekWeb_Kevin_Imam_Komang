<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Berhasil</title>
</head>
<body>
    <h1>Upload Berhasil!</h1>
    <p>Data tanah Anda telah berhasil disimpan.</p>
    <a href="uploadTanah.php">Kembali ke Form</a>
</body>
</html>
