<?php
session_start(); // Mulai sesi

// Jika parameter `action` adalah "clear", kosongkan keranjang
if (isset($_GET['action']) && $_GET['action'] === 'clear') {
    $_SESSION['keranjang'] = []; // Kosongkan seluruh keranjang
    echo "<script>alert('Keranjang telah dikosongkan!'); window.location.href = 'keranjang.php';</script>";
    exit();
}

// Pastikan parameter 'id' tersedia untuk menghapus item tertentu
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    if (isset($_SESSION['keranjang'])) {
        $keranjang = $_SESSION['keranjang'];
        $_SESSION['keranjang'] = array_filter($keranjang, function ($item) use ($id) {
            return $item['id'] != $id; // Simpan item yang ID-nya tidak sama dengan yang dihapus
        });

        echo "<script>alert('Item berhasil dihapus!'); window.location.href = 'keranjang.php';</script>";
    }
} else {
    echo "<script>alert('ID tidak valid.'); window.location.href = 'keranjang.php';</script>";
}
?>
