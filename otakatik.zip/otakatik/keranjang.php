<?php
include "dbConfig.php";
session_start(); // Mulai sesi

// Ambil data dari sesi keranjang
$keranjang = isset($_SESSION['keranjang']) ? $_SESSION['keranjang'] : [];

?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FindLand - Keranjang</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="keranjang.css">
</head>

<body>
<header>
        <nav>
            <div class="nav-left">
                <img src="images/WhatsApp Image 2024-11-29 at 08.55.29.jpeg" alt="logo-findland">
                <a href="index.html"><h1 class="title-large" style="color: black;">Find<span style="color: green;">Land</span></h1></a>
                <ul>
                    <li><a href="beranda.html">Beranda</a></li>
                    <li><a href="caritanah.html">Cari Tanah</a></li>
                    <li><a href="produk.html">Produk</a></li>
                    <li><a href="standarharga.html">Standar Harga Tanah</a></li>
                    <li><a href="edukasitanah.html">Edukasi</a></li>
                </ul>
            </div>
            <div class="nav-right">
                <ul>
                <li><a href="whistlist.html"><i class="bi bi-heart-fill"></i></a></li>
                <li><a href="setting.html"><i class="bi bi-chat-fill"></i></a></li>
                <li><a href="notifikasi.html"><i class="bi bi-bell-fill"></i></a></li>
                <h1>Username</h1>
                <img src="images/F9-768x639.png" alt="userprofile">
            </ul>
                <!-- <a href="login.html"><button>Login</button></a> -->
            </div>
        </nav>
    </header>

       <div class="content">
        <div class="hapus-semua">
            <h2>Favorit Saya</h2>
            
            <a href="hapusKeranjang.php?action=clear" class="clear-cart-button">Hapus Semua</a>
        </div>       
            <?php if (empty($keranjang)): ?>
                <p>Wishlist Anda kosong!</p>
            <?php else: ?>
                <?php foreach ($keranjang as $item): ?>
                    <div class="card">
                        <div class="card-header">
                            <h3>Rp. <?= number_format($item['harga'], 0, ',', '.'); ?></h3>
                        </div>
                        <div class="card-body">
                            <div class="left">
                                <img src="gambar/<?= $item['foto']; ?>" alt="Tanah Image">
                            </div>
                            <div class="right">
                                <p><strong>Lokasi:</strong> <?= $item['alamat']; ?></p>
                                <p><strong>Luas:</strong> <?= $item['luas']; ?> m&sup2;</p>
                                <p><strong>Sertifikat:</strong> <?= $item['sertifikat']; ?></p>
                                <p><strong>Deskripsi:</strong> <?= $item['deskripsi']; ?></p>
                                <a href="hapusKeranjang.php?id=<?= $item['id']; ?>" class="hapus-button">
                                    <i class="bi bi-trash"></i> 
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                <!-- <a href="hapusKeranjang.php?action=clear" class="clear-cart-button">Hapus Semua</a> -->
            <?php endif; ?>
        </div>
    </div>
</body>

</html>
