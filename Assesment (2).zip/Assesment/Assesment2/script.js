const container = document.querySelector('.review-container');
const btnLeft = document.querySelector('.scroll-left');
const btnRight = document.querySelector('.scroll-right');

// Scroll ke kiri
btnLeft.addEventListener('click', () => {
    container.scrollBy({ left: -300, behavior: 'smooth' });
});

// Scroll ke kanan
btnRight.addEventListener('click', () => {
    container.scrollBy({ left: 300, behavior: 'smooth' });
});
