<?php
include "template/header.php";
$sqlstatement = "SELECT * FROM tanah";
$query = mysqli_query($conn, $sqlstatement);
$dataTanah = mysqli_fetch_all($query, MYSQLI_ASSOC);
?>
<div class="buttons">
    <a href="tambahtanah.php"><button type="button" class="btn btn-primary">Tambah Data</button></a>
</div>
<div class="table">
    <!-- Tabel dengan kelas Bootstrap -->
    <table class="table table-striped table-bordered table-hover table-rounded mt-3">
        <thead class="table-secondary">
            <tr>
                <th>Judul</th>
                <th>Luas</th>
                <th>harga</th>
                <th>Alamat</th>
                <th>Sertifikat</th>
                <th>Deskripsi</th>
                <th>foto</th>
                <th>aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($dataTanah as $key => $tanah): ?>
                <tr>
                    <td><?php echo $tanah['judul']; ?></td>
                    <td><?php echo $tanah['luas']; ?></td>
                    <td><?php echo $tanah['harga']; ?></td>
                    <td><?php echo $tanah['alamat']; ?></td>
                    <td><?php echo $tanah['sertifikat']; ?></td>
                    <td><?php echo $tanah['deskripsi']; ?></td>
                    <td> <img src="../Assesment2/images/<?=$tanah['foto']; ?>" alt="Tanah Image" class="card-image"></td>
                    <td align="center">
                        <a href="edittanah.php?id=<?= $tanah["id"] ?>" class="btn btn-sm btn-primary">Edit</a>
                        <a href="deleteTanah.php?id=<?= $tanah["id"] ?>" class="btn btn-sm btn-danger"
                            onclick="return confirm('Yakin akan menghapus?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>

</html>