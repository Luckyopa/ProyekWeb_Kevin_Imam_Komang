<?php session_start(); 
include "koneksi.php" ; 
define('HOST', "http://localhost/assesment2/index.html" ); ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>dashboard admin</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
            crossorigin="anonymous"></script>
        <style>
            .sidebar {
                height: 100vh;
                /* Menyesuaikan tinggi sidebar dengan layar */
                position: fixed;
                /* Membuat sidebar tetap pada posisi */
                top: 100px;
                left: 0;
                width: 250px;
                /* Lebar sidebar */
                background-color: #ffff;
                padding-top: 20px;
                margin-right: 20px;
            }

            .sidebar a {
                display: block;
                padding: 15px;
                text-decoration: none;
                color: #333;
                font-size: 16px;
            }

            .sidebar a:hover {
                background-color: #99b674;
                color: white;
            }

            .table {
                margin-top: 10px;
                max-width: 1000px;
                margin-left: 200px;
            }

            .buttons {
                margin-left: 400px;
                margin-top: 50px;
            }
            
            nav {
                display: flex;
                align-items: center;
              
                justify-content: space-between;
              }
            .nav-left {
                width: auto;
                height: auto;
                display: flex;
                align-items: center;
            }

            .nav-left a {
                text-decoration: none;
              }

            .nav-right {
                width: auto;
                height: auto;
                display: flex;
            }

            .nav-left h1 {
                font-family: Arial, Helvetica, sans-serif;
                font-weight: bold;
            }

            .nav-right a button {
                color: white;
                font-family: Arial, Helvetica, sans-serif;
                font-weight: bold;
                text-decoration: none;
                background-color: #99b674;
                border: none;
                width: 100px;
                height: 50px;
                border-radius: 6px;
                margin-right: 50px;
                box-shadow: 1px 1px 3px 1px rgb(167, 167, 167);
             }

             .nav-right a button:hover {
                color: white;
                font-family: Arial, Helvetica, sans-serif;
                font-weight: bold;
                text-decoration: none;
                background-color: #7a915c;
                border: none;
                width: 100px;
                height: 50px;
                border-radius: 6px;
                margin-right: 50px;
                box-shadow: 1px 1px 1px 1px rgb(167, 167, 167);
            }

            nav img {
                width: 100px;
                height: 100px;
            }
        </style>
    </head>

    <body>
        <nav class="navbar">
            <div class="nav-left">
                    <img src="../images/logo.png" alt="logo-findland">
                    <a href="index.html">
                        <h1 style="color: black;">Find<span style="color: green;">Land</span></h1>
                    </a>
            </div>
            <div class="nav-right">
                <a href="../Register.php"><button>Logout</button></a>
            </div>
        </nav>
        <div class="sidebar">
            <!-- <a href="index.php">Dashboard</a> -->
            <a href="user.php"><i class="bi bi-person-fill"></i>User</a>
            <a href="tanah.php"><i class="bi bi-globe-asia-australia"></i>Tanah</a>
            <a href="produk.php"><i class="bi bi-basket"></i>Produk</a>
            <a href="standarharga.php"><i class="bi bi-coin"></i>Standar Harga</a>
        </div>
    </body>