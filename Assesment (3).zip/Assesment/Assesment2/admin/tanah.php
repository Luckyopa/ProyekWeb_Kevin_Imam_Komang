<?php
include "template/header.php";
include "koneksi.php";
$sqlstatement = "SELECT * FROM tanah";
$query = mysqli_query($conn, $sqlstatement);
$dataTanah = mysqli_fetch_all($query, MYSQLI_ASSOC);
?>
<div class="buttons">
    <a href="tambahtanah.php"><button type="button" class="btn btn-success">Tambah Data <style>button { background-color: #99b674; border-radius: 6px; color: white; width: 120px; height: 38px; border-color: #99b674;}</style></button></a>
</div>
<div class="table">
    <!-- Tabel dengan kelas Bootstrap -->
    <table class="table table-striped table-bordered table-hover table-rounded mt-3">
        <thead class="table-secondary">
            <tr>
                <th>Judul</th>
                <th>Luas</th>
                <th>harga</th>
                <th>Alamat</th>
                <th>Sertifikat</th>
                <th>Deskripsi</th>
                <th>foto</th>
                <th>aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($dataTanah as $tanah): ?>
                <tr>
                    <td><?php echo $tanah['judul']; ?></td>
                    <td><?php echo $tanah['luas']; ?></td>
                    <td><?php echo $tanah['harga']; ?></td>
                    <td><?php echo $tanah['alamat']; ?></td>
                    <td><?php echo $tanah['sertifikat']; ?></td>
                    <td><?php echo $tanah['deskripsi']; ?></td>
                    <td> <img src="../images/<?=$tanah['foto']; ?>" alt="Tanah Image" class="card-image"><style>img { width: 50px; height: 40px; }</style></td>
                    <td align="center">
                        <a href="edittanah.php?id=<?= $tanah["id"] ?>" class="btn btn-sm btn-primary">Edit</a>
                        <a href="deleteTanah.php?id=<?= $tanah["id"] ?>" class="btn btn-sm btn-danger"
                            onclick="return confirm('Yakin akan menghapus?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>

</html>