<?php
include "koneksi.php";
include "template/header.php";
$sqlstatement = "SELECT * FROM produk";
$query = mysqli_query($conn, $sqlstatement);
$dataProduk = mysqli_fetch_all($query, MYSQLI_ASSOC);
?>
<div class="buttons">
    <a href="tambahproduk.php"><button type="button" class="btn btn-success">Tambah Data <style>button { background-color: #99b674; border-radius: 6px; color: white; width: 120px; height: 38px; border-color: #99b674;}</style></button></a>
</div>
<div class="table">
    <!-- Tabel dengan kelas Bootstrap -->
    <table class="table table-striped table-bordered table-hover table-rounded mt-3">
        <thead class="table-secondary">
            <tr>
                <th>Foto</th>
                <th>Nama</th>
                <th>harga</th>
                <th>tipe</th>
                <th>lokasi</th>
                <th>aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($dataProduk as $key => $produk): ?>
                <tr>
                    <td> <img src="../images/<?=$produk['foto']; ?>" alt="Tanah Image" class="card-image"><style>img { width: 50px; height: 40px; }</style></td>
                    <td><?php echo $produk['nProduk']; ?></td>
                    <td><?php echo $produk['harga']; ?></td>
                    <td><?php echo $produk['tipe']; ?></td>
                    <td><?php echo $produk['lokasi']; ?></td>
                    <td align="center">
                        <a href="editproduk.php?id=<?= $produk["idProduk"] ?>" class="btn btn-sm btn-primary">Edit</a>
                        <a href="deleteproduk.php?id=<?= $produk["idProduk"] ?>" class="btn btn-sm btn-danger"
                            onclick="return confirm('Yakin akan menghapus?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>

</html>