<?php
include "koneksi.php";
include "template/header.php";

// Proses form jika disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $foto = $_FILES['foto'];
    if (!empty($foto['name'])) {
        $photoname = time() . '_' . $foto['name'];
        move_uploaded_file($foto['tmp_name'], '../images/' . $photoname);
    } else {
        $photoname = "";
    }
    $nProduk = $_POST['nProduk'];
    $harga = $_POST['harga'];
    $tipe = $_POST['tipe'];
    $lokasi = $_POST['lokasi'];

    // Tambah data tanah
    $insert_sql = "INSERT INTO produk (nProduk, harga, tipe, lokasi, foto) VALUES ('$nProduk', '$harga', '$tipe', '$lokasi', '$photoname')";

    if ($conn->query($insert_sql) === TRUE) {
        echo "Data tanah berhasil ditambahkan.";
        header("Location:produk.php"); // Redirect ke halaman tanah setelah berhasil
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            margin-left: 300px;
            max-width: 400px;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2>Tambah Produk</h2>
    <form method="POST" enctype="multipart/form-data" >
        <div class="mb-3">
            <label for="nProduk" class="form-label">Nama Produk</label>
            <input type="text" class="form-control" id="nProduk" name="nProduk" required>
        </div>
        <div class="mb-3">
            <label for="harga" class="form-label">Harga</label>
            <input type="text" class="form-control" id="harga" name="harga" required>
        </div>
        <div class="mb-3">
            <label for="tipe" class="form-label">Tipe</label><br>
            <select name="tipe" id="">
                <option value="Alat">Alat</option>
                <option value="Mesin">Mesin</option>
                <option value="Bahan">Bahan</option>
                <option value="Benih dan Tanaman">Benih dan Tanaman</option>
                <option value="Dekorasi">Dekorasi</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="lokasi" class="form-label">Lokasi</label>
            <input type="text" class="form-control" id="lokasi" name="lokasi" required>
        </div>
        <div class="mb-3">
            <label for="foto" class="form-label">Foto</label>
            <input type="file" class="form-control" id="foto" name="foto">
        </div>
        <button type="submit" class="btn btn-primary">Tambah Produk</button>
    </form>
</div>
</body>
</html>